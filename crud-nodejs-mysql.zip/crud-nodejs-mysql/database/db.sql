-- creando DB
CREATE DATABASE myBDCrud;

-- usar BD
use myBDCrud;

-- creat tabla clientes
create table clientes (
    id int(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    direccion VARCHAR(100) NOT NULL,
    tipo_id int(6) NOT NULL,
    num_id int(25) NOT NULL,
    telefono VARCHAR(15),
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP, 
    fecha_modifica DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
);

-- mostrar table
show tables;

-- describe table
describe clientes;