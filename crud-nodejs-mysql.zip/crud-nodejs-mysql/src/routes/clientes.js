const express = require('express');
const router = express.Router();

const clientesController = require('../controllers/clientesController');
const reportesController = require('../controllers/reportesController');

// Listar url
router.get('/', clientesController.list);
router.post('/add', clientesController.save);
router.get('/delete/:id', clientesController.delete);
router.get('/update/:id', clientesController.edit);
router.post('/update/:id', clientesController.update);
router.get('/generarReporte', reportesController.reporteCSV);

module.exports = router;