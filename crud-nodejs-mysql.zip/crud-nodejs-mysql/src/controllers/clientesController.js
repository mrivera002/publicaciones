controller = {};

// Metodo para hacer consulta de los registros
controller.list = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('select * from clientes', (err, rows) => {
            if (err) {
                res.json(err);
            } else {
                res.render('clientes', {
                    data: rows
                });
            }
        });
    });
};

//  Metodo para agregar un nuevo registro
controller.save = (req, res) => {
    const data = req.body;
    console.log(req.body)
    req.getConnection((err, conn) => {
        conn.query('insert into clientes set ?', [data], (err, rows) => {
            if (err) {
                res.json(err);
            } else {
                res.redirect('/');
            }
        });
    }); 
};

//  Metodo para seleccionar un registro para actualizarlo posteriormente
controller.edit = (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        conn.query('select * from clientes where id = ?', [id], (err, rows) => {
            if (err) {
                res.json(err);
            } else {
                res.render('clientes_edit', {
                    data: rows[0]
                });
            }
        });
    }); 
};

//  Metodo para actualizar un registro
controller.update = (req, res) => {
    const { id } = req.params;
    const updateCliente = req.body;
    req.getConnection((err, conn) => {
        conn.query('update clientes set ? where id = ?', [updateCliente, id], (err, rows) => {
            if (err) {
                res.json(err);
            } else {
                res.redirect('/');
            }
        });
    }); 
};

//  Metodo para eliminar un registro
controller.delete = (req, res) => {
    const { id } = req.params;
    req.getConnection((err, conn) => {
        conn.query('delete from clientes where id = ?', [id], (err, rows) => {
            if (err) {
                res.json(err);
            } else {
                res.redirect('/');
            }
        });
    }); 
};

module.exports = controller;