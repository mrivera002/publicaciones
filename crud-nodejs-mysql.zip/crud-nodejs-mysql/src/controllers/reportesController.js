const fs = require('fs');
const ObjectsToCsv = require('objects-to-csv');

controller = {};

// Metodo para hacer consulta de los registros y generar el reporte CSV
controller.reporteCSV = (req, res) => {
    req.getConnection((err, conn) => {
        conn.query('select nombre,direccion, case when tipo_id = 1 then "DUI" when tipo_id = 2 then "PASAPORTE" when tipo_id = 3 then "LICENCIA DE CONDUCIR" end as tipo_documento,num_id as numero_documento,telefono from clientes', async(err, rows) => {
            if (err) {
                res.json(err);
            } else {
                const csv = new ObjectsToCsv(rows);
                await csv.toDisk('./reporte.csv');
                console.log(await csv.toString());
                res.download('./reporte.csv', () => {
                    fs.unlinkSync('./reporte.csv');
                });
            }
        });
    });
}


module.exports = controller;